import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Cars extends PApplet {

Car myCar1;
Car[] myCars = new Car[10];

public void setup() {
  
  myCar1 = new Car(random(width), random(height), random(10));
  for (int i=0; i<myCars.length; i++) {
    myCars[i] = new Car(random(width), random(height), random(10));
  }
}

public void draw() {
  background(255);
  myCar1.display();
  myCar1.drive();
  for (int i=0; i<myCars.length; i++) {
    myCars[i].display();
    myCars[i].drive();
  }
}
class Car {
  // Member Variables
  int c;
  float x;
  float y;
  float s;
  boolean right;

  // Constructer
  Car(float x, float y, float s) {
    c = color(random(250),random(250),random(250));
    this.x = x;
    this.y = y;
    this.s = s;
    if (random(10)>5) {
      right = false;
    } else {
      right=true;
    }
  }
  // Display Method
  public void display() {
    rectMode(CENTER);
    fill(c);
    rect(x, y, 20, 10);
    fill(0);
    rect(x-7, y-7, 7, 2);
    rect(x-7, y+7, 7, 2);
    rect(x+6, y-7, 7, 2);
    rect(x+6, y+7, 7, 2);
  }

  // Drive Method
  public void drive() {
    if (right) {
      x+=s;
      if (x>width) {
        x=0;
      }
    } else {
      x-=s;
      if (x<0) {
        x=width;
      }
    }
  }
}
  public void settings() {  size(900,900); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--present", "--window-color=#666666", "--stop-color=#cccccc", "Cars" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
