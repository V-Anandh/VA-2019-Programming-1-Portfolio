import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Etch_A_Sketch extends PApplet {

int x, y;
public void setup() {
  
  frameRate(30);
  // Set start coords
  x = 0;
  y = 0;
}
public void draw() {
  fill(255);
  //drawName();
  //noLoop();
  keyPressed();
}
public void mouseClicked() {
  saveFrame("line-######.png");
}
// Algorithm for your first name
public void drawName() {
  strokeWeight(5);
  moveLeft(10);
  moveDown(20);
  moveRight(12);

  //moveUp(10);
  moveRightDown(5);
  //moveLeft(10);
  moveRightUp(5);
  //moveUp(25);
  //moveRight(2);
  moveRight(2);
  moveLeft(2);
  moveLeftDown(5);
  moveLeftUp(5);
  moveLeft(3);
  moveDown(5);
  strokeWeight(1);
  //noStroke();
  moveRight(41);
  strokeWeight(5);
  moveLeftUp(PApplet.parseInt(2.5f));
  moveRightUp(PApplet.parseInt(2.5f));
  moveLeftDown(PApplet.parseInt(2.5f));
  moveUp(PApplet.parseInt(2.5f));
  moveDown(4);
  strokeWeight(1);
  moveLeft(5);
  strokeWeight(5);
  moveUp(4);
  moveRight(2);
  moveLeft(2);
  moveDown(2);
  moveRight(2);
  moveLeft(2);
  moveDown(2);
  strokeWeight(5);
  moveRight(2);
  strokeWeight(1);
  moveLeft(9);
  moveRightUp(4);
  strokeWeight(5);
  moveLeftDown(4);
  moveLeftUp(4);
  strokeWeight(1);
  moveRightDown(4);
  moveLeft(9);
  strokeWeight(5);
  moveUp(3);
  moveUp(1);
  strokeWeight(5);
  moveLeft(2);
  moveRight(4);
  moveLeft(2);
  moveDown(4);
  moveLeft(2);
  moveRight(4);
}
public void moveRight(int rep) {
  for (int i=0; i<rep*10; i++) {
    point(x+i, y);
  }
  x=x+(10*rep);
}
public void moveLeft(int rep) {
  for (int i=0; i<rep*10; i++) {
    point(x-i, y);
  }
  x=x-(10*rep);
}
public void moveUp(int rep) {
  for (int i=0; i<rep*10; i++) {
    point(x, y-i);
  }
  y=y-(10*rep);
}
public void moveDown(int rep) {
  for (int i=0; i<rep*10; i++) {
    point(x, y+i);
  }
  y=y+(10*rep);
}
public void moveRightDown(int rep) {
  for (int i=0; i<rep*10; i++) {
    point(x+i, y+i);
  }
  x=x+(10*rep);
  y=y+(10*rep);
}
public void moveLeftDown(int rep) {
  for (int i=0; i<rep*10; i++) {
    point(x-i, y+i);
  }
  x=x-(10*rep);
  y=y+(10*rep);
}
public void moveRightUp(int rep) {
  for (int i=0; i<rep*10; i++) {
    point(x+i, y-i);
  }
  x=x+(10*rep);
  y=y-(10*rep);
}
public void moveLeftUp(int rep) {
  for (int i=0; i<rep*10; i++) {
    point(x-i, y-i);
  }
  x=x-(10*rep);
  y=y-(10*rep);
}
public void keyPressed() {
  if (key == CODED) {
    if (keyCode == RIGHT) {
      moveRight(1);
    } else if (keyCode == DOWN) {
      moveDown(1);
    } else if (keyCode == UP) {
      moveUp(1);
    } else if (keyCode == LEFT) {
      moveLeft(1);
    }
  }
}
  public void settings() {  size(400, 400); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--present", "--window-color=#666666", "--stop-color=#cccccc", "Etch_A_Sketch" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
