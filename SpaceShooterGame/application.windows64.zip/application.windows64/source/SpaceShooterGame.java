import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.sound.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class SpaceShooterGame extends PApplet {

// SpaceShooter App 2018
// by Vivek Anandh
// To Do:

// Global Variables for Game Logic
PImage img;
PImage img1;
ArrayList<SpaceRock> rock;
Spaceship ship;
ArrayList<Laser> lasers;
int rockRate = 1000;
Timer timer;
Timer ticTimer;
int level = 1;
boolean ticker = false;
int score = 0;
boolean play = false;
int Health = 100;   

String ticText;


public void setup() {
  img = loadImage("bkrndjpg.jpeg");
  rock = new ArrayList<SpaceRock>();
  
  ship = new Spaceship(100);
  lasers = new ArrayList<Laser>();
  timer = new Timer(rockRate);
  timer.start();
  ticTimer = new Timer(2000);
}


public void draw() {

  textAlign(LEFT);
  image(img, 0, 0);
  noCursor();
  if (ship.health <= 0) {
    gameOver();
  }
  if (!play) {
    if (ship.health >= 100) {
      startScreen();
    } else {
      gameOver();
    }
  } else if (play) {


    if (frameCount % 1000 == 10) {
      level++;

      ticText = "Level: " + level;
      ticker();
      rockRate-=50;
      timer.totalTime = rockRate;
    }

    for (int i= rock.size()-1; i>=0; i--) {
      SpaceRock rocks = (SpaceRock) rock.get(i);
      rocks.move();
      rocks.display();
      if (rocks.reachBottom()) {
        rock.remove(rocks);
        ship.health -= 5;
      }
      // Collision Detection
      for (int j = lasers.size()-1; j>=0; j--) {
        Laser l = (Laser) lasers.get(j);
        if (dist(l.x, l.y, rocks.x, rocks.y)<rocks.r/2) {
          score += random(5, 10);
          rocks.health -= 10;
          //lasers.remove(l);
          // include sounds
        }
        if (rocks.health<1) {
          rock.remove(rocks);
        }
      }
      if (dist(ship.x, ship.y, rocks.x, rocks.y) < ship.r) {
        if (rocks.isPU) {
          rock.remove(rocks);
            ship.health +=10;
        } else {
          rock.remove(rocks);
          ship.health -= 10;
        }
      }
    } 

    if (timer.isFinished()) {
      if (random(101)>10) {
        rock.add(new SpaceRock(PApplet.parseInt(random(width)), -20, false));
      } else {
        rock.add(new SpaceRock(PApplet.parseInt(random(width)), -20, true));
      }
      timer.start();
    }
    if (ticker) {
      if (!ticTimer.isFinished()) {
        fill(255);
        textSize(50);
        textAlign(CENTER);
        text(ticText, width/2, height/2);
      } else if (!ticTimer.isFinished() && ship.health < 30) {
        fill(255);
        textSize(44);
        textAlign(CENTER);
        text(ticText, width/2, height/2);
      }
    }
    textAlign(LEFT);
    for (int k = 0; k<lasers.size(); k++) {
      lasers.get(k).fire();
      lasers.get(k).display();
      if (lasers.get(k).reachTop()) {
        lasers.remove(k);
      }
    }
    ship.setPlace(mouseX, mouseY);
    ship.display();
    updateDisplay();
  }
  if (score >= 1000) {
  }
}
public void updateDisplay() {
  fill(50, 8000);
  rect(10, 10, 150, 50);
  fill(255);
  textSize(15);
  text("Score: " + score, 15, 50);
  text("Ship Health: " + ship.health, 15, 30);
}
public void startScreen() {
  background(0);
  textSize(90);
  text("Space Adventure", width/20, height/2);
  text("Click to Play", width/8, height/1.5f);

  if (mousePressed) {
    play = true;
  }
}
public void gameOver() {
  background(0);
  play = false;
  rock.clear();
  textSize(90);
  text("GAME OVER", width/6, height/3);
  textSize(20);
  text("YOU HAVE BEEN DEFEATED BY A COMPUTER", width/4.5f, height/2);
  text("IT'S TIME FOR AI TO TAKE OVER THE WORLD", width/4.5f, height/1.75f);
  text("PRESS ENTER TO TRY OVER", width/4.5f, height/1.5f);

  if (key == ENTER) {
    startScreen();
    ship.health = 100;
  }
}


public void ticker() {
  ticTimer.start();
  ticker = true;
  if (ticTimer.isFinished()) {
    ticker = false;
  }
}

public void mousePressed() {
  lasers.add(new Laser(ship.x, ship.y));

}

public void keyReleased() {
  if (key == ' ') {
    lasers.add(new Laser(ship.x, ship.y));
  }
}


public void keyPressed() {
  if (key == ' ') {
    lasers.add(new Laser(ship.x, ship.y));

  }
}
 class EnemyLaser {
  int x, y, w, h;
  int c1;
  float speed;
  EnemyLaser(int x, int y, int  w, int h, int c1, float speed) {
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.c1 = c1;
    this.speed = speed;
  }
  public void EnemyFire() {
    rect(x, y, w, h);
  }
}
class Laser {
  int x, y, w, h;
  int c;
  float speed;
  boolean laspow;

  Laser(int x, int y) {
    this.x = x;
    this.y = y;
    w = 10;
    h = 25;
    c = color(0, 255, 0);
    speed= 30;
    laspow = false;
  }
  public void fire() {
    y -= speed;
  }
  public boolean reachTop() {
    if (y<0 -50) {
      return true;
    } else {
      return false;
    }
  }
  public void display() {
    noStroke();
    fill(255,0, 0);
    ellipse(x+20, y-20, 10, 10);
    ellipse(x-20, y-20, 10, 10);
  }
}
class SpaceRock {
  int x, y, r, health, speed, c;
  boolean isPU;
  SpaceRock(int x, int y, boolean isPU) {
    this.x = x;
    this.y = y;
    r = PApplet.parseInt(random(50, 200));
    speed= PApplet.parseInt(random(1, 6));
    health = r;
    c = color(random(100, 175));
    this.isPU = isPU;
  }
  public void move() {
    y+= speed;
  }
  public boolean reachBottom() {
    if (y> height + r) {
      return true;
    } else {
      return false;
    }
  }
  public void display() {
    if (isPU) {
      fill(255);
    } else {
      fill(c);
    }
    noStroke();
    ellipse(x, y, health, health);
    fill(255);
    if (isPU) {
      fill(0);
      text("PU", x-5, y+5);
    } else {
      fill(c);
    }
  }
}
class Spaceship {
  //Member Variables
  int x, y, r;
  int health;
  //float speed;
  //constructor
  Spaceship(int r) {
    this.r = r;
    health = 100;
  }
  
  public void setPlace(int x, int y) {
    this.x = x;
    this.y = y;    
  }
  public void display() {
    rectMode(CORNER);
    stroke(0);
    fill(230, 231, 233);
    ellipse(x, y-5, 28, 80);
    fill(233, 50, 39);
    triangle(x, y-5-45, x-10, y-5-30, x+10, y-5-30);
    fill(76, 171, 235);
    ellipse(x, y-5-10, 15, 15);
    fill(233, 50, 39);
    triangle(x-15, y-5+10, x-20, y-5+40, x-10, y-5+30);
    fill(233, 50, 39);
    triangle(x+15, y-5+10, x+20, y-5+40, x+10, y-5+30);
    fill(255);
    noStroke();
    rect(x-9, y-5+30, 18, 14);
    stroke(0);
    line(x-9, y-5+30, x+9, y-5+30);
    fill(168, 169, 171);
    quad(x-9, y-5+30, x-8, y-5+33, x+8, y-5+33, x+9, y-5+30);
    quad(x-8, y-5+33, x-9, y-5+36, x+9, y-5+36, x+8, y-5+33);
    fill(2549, 216, 1);
    noStroke();
    triangle(x-9, y-5+37, x+9, y-5+37, x, y-5+55);
    triangle(x-9, y-5+37, x, y-5+37, x-11, y-5+49);
    triangle(x, y-5+37, x+9, y-5+37, x+11, y-5+49);
    stroke(0);
    fill(233, 50, 39);
    rect(x-2, y-5+6, 4, 39);
    line(x-9, y-5+37, x-11, y-5+49);
    line(x+9, y-5+37, x+11, y-5+49);
    line(x, y-5+55, x+6, y+38);
    line(x, y-5+55, x-6, y+38);
    line(x+6, y+38, x+11, y-5+49);
    line(x-6, y+38, x-11, y-5+49);
  }
}
class Timer {

  int savedTime; // When Timer started
  int totalTime; // How long Timer should last

  Timer(int tempTotalTime) {
    totalTime = tempTotalTime;
  }

  // Starting the timer
  public void start() {
    // When the timer starts it stores the current time in milliseconds.
    savedTime = millis();
  }

  // The function isFinished() returns true if 5,000 ms have passed. 
  // The work of the timer is farmed out to this method.
  public boolean isFinished() { 
    // Check how much time has passed
    int passedTime = millis()- savedTime;
    if (passedTime > totalTime) {
      return true;
    } else {
      return false;
    }
  }
}
  public void settings() {  size(800, 1000); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--present", "--window-color=#666666", "--stop-color=#cccccc", "SpaceShooterGame" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
