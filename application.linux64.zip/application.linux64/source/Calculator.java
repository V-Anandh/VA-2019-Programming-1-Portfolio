import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Calculator extends PApplet {

PImage img;
int DrkGryBtn = color(89, 89, 89);
int LtGryBtn = color(221, 221, 221);
int B1 = color(45, 111, 250);
int G1 = color(0, 2720000, 0);
int R1 = color(5000000, 0, 0);
int Y1 = color(450, 442, 0);
int B = color(0, 0, 255, 200);
int G = color(15, 215, 0);
int R = color(215, 0, 15);
int Y = color(225, 221, 0);
int GF = color(93, 194, 30);
int BF =color(0);
int W = color(255);
int Blk = color(150);
String displayVal, leftVal, rightVal;
char opVal;
float result;
boolean firstNum, dec;
int displaySize;
Button[] numBtns = new Button[10];
Button[] opBtns = new Button[12];
//Button btn0,1

public void setup() {
  
  img = loadImage("controller.jpg");
  displayVal = "";
  leftVal = "";
  displaySize = 34;
  rightVal = "";
  opVal = ' ';
  result = 0.0f;
  firstNum = true;
  dec = false;
  numBtns[0] = new Button(255, 300, 25, 25, 0, LtGryBtn, GF, W);
  numBtns[1] = new Button(225, 210, 25, 25, 1, LtGryBtn, GF, W);
  numBtns[2] = new Button(255, 210, 25, 25, 2, LtGryBtn, GF, W);
  numBtns[3] = new Button(285, 210, 25, 25, 3, LtGryBtn, GF, W);
  numBtns[4] = new Button(225, 240, 25, 25, 4, LtGryBtn, GF, W);
  numBtns[5] = new Button(255, 240, 25, 25, 5, LtGryBtn, GF, W);
  numBtns[6] = new Button(285, 240, 25, 25, 6, LtGryBtn, GF, W);
  numBtns[7] = new Button(225, 270, 25, 25, 7, LtGryBtn, GF, W);
  numBtns[8] = new Button(255, 270, 25, 25, 8, LtGryBtn, GF, W);
  numBtns[9] = new Button(285, 270, 25, 25, 9, LtGryBtn, GF, W);

  opBtns[0] = new Button(225, 300, 26, 26, 0, LtGryBtn, GF, W).asOperator("±");
  opBtns[1] = new Button(285, 300, 26, 26, 0, LtGryBtn, GF, W).asOperator(".");
  opBtns[2] = new Button(195, 325, 39, 39, 0, DrkGryBtn, BF, Blk).asOperator("C");
  opBtns[3] = new Button(315, 325, 39, 39, 0, DrkGryBtn, BF, Blk).asOperator("=");
  opBtns[4] = new Button(150, 230, 30, 30, 0, DrkGryBtn, BF, Blk).asOperator("√");
  opBtns[5] = new Button(150, 280, 30, 30, 0, DrkGryBtn, BF, Blk).asOperator("CE");
  opBtns[6] = new Button(125, 255, 30, 30, 0, DrkGryBtn, BF, Blk).asOperator("^");
  opBtns[7] = new Button(175, 255, 30, 30, 0, DrkGryBtn, BF, Blk).asOperator("x²");
  opBtns[8] = new Button(370, 230, 30, 30, 0, Y, BF, Y1).asOperator("+");
  opBtns[9] = new Button(370, 280, 30, 30, 0, G, BF, G1).asOperator("-");
  opBtns[10] = new Button(345, 255, 30, 30, 0, B, BF, B1).asOperator("x");
  opBtns[11] = new Button(395, 255, 30, 30, 0, R, BF, R1).asOperator("÷");
}
public void draw() {
  background(255);
  image(img, 10, 0);
  for (int i=0; i<numBtns.length; i++) {
    numBtns[i].display();
    numBtns[i].hover();
  }
  for (int i=0; i<opBtns.length; i++) {
    opBtns[i].display();
    opBtns[i].hover();
  }
  if (displayVal.length()<9) {
    displaySize =  34;
  } else if (displayVal.length()*displaySize>460) {
    displaySize /=1.5f;
  }
  updateDisplay();
}
public void updateDisplay() {
  TV();
  rectMode(CENTER);
  fill(255);
  rect(250, 75, 290, 110);
  fill(0);
  textSize(displaySize);
  textAlign(RIGHT);
  text(displayVal, 395, 80);
}
public void mouseReleased() {
  for (int i=0; i<numBtns.length; i++) {
    if (numBtns[i].hov) {
      if (firstNum) {
        leftVal += str(numBtns[i].v);
        displayVal = leftVal;
      } else {
        rightVal += str(numBtns[i].v);
        displayVal = rightVal;
      }
    }
  }
  for (int i=0; i<opBtns.length; i++) {
    if (opBtns[i].hov) {
      if (opBtns[i].op == "+") {
        opVal = '+';
        displayVal = leftVal +"+";
        firstNum = false;
        dec = false;
      }
      if (opBtns[i].op == "-") {
        opVal = '-';
        displayVal = leftVal + "-";
        firstNum = false;
        dec = false;
      }
      if (opBtns[i].op == "x") {
        opVal = 'x';
        displayVal = leftVal + "x";
        firstNum = false;
        dec = false;
      } 
      if (opBtns[i].op == "÷") {
        opVal = '÷';
        displayVal = leftVal + "/";
        firstNum = false;
        dec = false;
      } else if (opBtns[i].op == "√") {
        if (firstNum) {
          leftVal = str(sqrt(PApplet.parseFloat(leftVal)));
          displayVal = leftVal;
        } else {
          rightVal = str(sqrt(PApplet.parseFloat(rightVal)));
          displayVal = rightVal;
        }
      } else if (opBtns[i].op == "x²") {
        if (firstNum) {
          leftVal = str(sq(PApplet.parseFloat(leftVal)));
          displayVal = leftVal;
        } else {
          rightVal = str(sq(PApplet.parseFloat(rightVal)));
          displayVal = rightVal;
        }
      } 
      if (opBtns[i].op == "^") {
        opVal = '^';
        displayVal = leftVal+ rightVal;
        firstNum = false;
        dec = false;
      } else if (opBtns[i].op == "=") {
        performCalc();
      } else if (opBtns[i].op == "C") {
        clearApp();
      } else if (opBtns[i].op == ".") {
        if (!dec) {
          if (firstNum) {
            leftVal += opBtns[i].op;
            displayVal = leftVal;
            dec = true;
          } else {
            rightVal += opBtns[i].op;
            displayVal = rightVal;
            dec = true;
          }
        }
      } else if (opBtns[i].op == "CE") {
        if (firstNum) {
          leftVal = "";
          displayVal = leftVal;
        } else {
          rightVal = "";
          displayVal = rightVal;
        }
      } else if (opBtns[i].op == "±") {
        if (firstNum) {
          leftVal = str(PApplet.parseFloat(leftVal) * -1);
          displayVal = leftVal;
        } else {
          rightVal = str(PApplet.parseFloat(rightVal) * -1);
          displayVal = rightVal;
        }
      }
    }
  }
}

public void performCalc() {
  if (opVal == '+') {
    result = PApplet.parseFloat(leftVal) + PApplet.parseFloat(rightVal);
    displayVal= str(result);
  }
  if (opVal == '-') {
    result = PApplet.parseFloat(leftVal) - PApplet.parseFloat(rightVal);
    displayVal= str(result);
  }
  if (opVal == 'x') {
    result = PApplet.parseFloat(leftVal) * PApplet.parseFloat(rightVal);
    displayVal= str(result);
  }
  if (opVal == '÷') {
    result = PApplet.parseFloat(leftVal) / PApplet.parseFloat(rightVal);
    displayVal= str(result);
  }
  if (opVal == '^') {
    result =pow(PApplet.parseFloat(leftVal), PApplet.parseFloat(rightVal));
    displayVal= str(result);
  }
  leftVal = displayVal;
  firstNum = true;
  dec = false;
}

public void clearApp() {
  displayVal = "0.0";
  leftVal = "";
  rightVal = "";
  opVal = ' ';
  result = 0.0f;
  firstNum = true;
  dec = false;
}
public void keyPressed() {
  if (key == '1') {
    handleKeyPress(true, "1");
  } else if (key == '2') {
    handleKeyPress(true, "2");
  } else if (key == '3') {
    handleKeyPress(true, "3");
  } else if (key == '4') {
    handleKeyPress(true, "4");
  } else if (key == '5') {
    handleKeyPress(true, "5");
  } else if (key == '6') {
    handleKeyPress(true, "6");
  } else if (key == '7') {
    handleKeyPress(true, "7");
  } else if (key == '8') {
    handleKeyPress(true, "8");
  } else if (key == '9') {
    handleKeyPress(true, "9");
  } else if (key == '0') {
    handleKeyPress(true, "0");
  } else if (key == '+') {
    handleKeyPress(false, "+");
  } else if (key == '-') {
    handleKeyPress(false, "-");
  } else if (key == '*') {
    handleKeyPress(false, "x");
  } else if (key == '/') {
    handleKeyPress(false, "÷");
  } else if (key == ENTER) {
    handleKeyPress(false, "=");
  } else if (key == '=') {
    handleKeyPress(false, "=");
  } else if (key == 'c') {
    handleKeyPress(false, "C");
  } else if (key == BACKSPACE) {
    handleKeyPress(false, "CE");
  } else if (key == '.') {
    handleKeyPress(false, ".");
  } else if (key == '^') {
    handleKeyPress(false, "^");
  } else if (key == '√') {
    handleKeyPress(false, "√");
  }
}
public void handleKeyPress(boolean num, String val) {
  if (num) {
    if (firstNum) {
      leftVal += val;
      displayVal = leftVal;
    } else {
      rightVal += val;
      displayVal = rightVal;
    }
  } 
  if (!num) {
    if (val == "+") {
      opVal = '+';
      displayVal = leftVal +"+";
      firstNum = false;
      dec = false;
    }     
    if (val == "-") {
      opVal = '-';
      displayVal = leftVal +"-";
      firstNum = false;
      dec = false;
    }
    if (val == "x") {
      opVal = 'x';
      displayVal = leftVal + "x";
      firstNum = false;
      dec = false;
    }
    if (val == "÷") {
      opVal = '÷';
      displayVal = leftVal + "/";
      firstNum = false;
      dec = false;
    }      
    if (val == "=") {
      performCalc();
    }
    if (val == "C") {
      clearApp();
    }
    if (val == "CE") {
      if (firstNum) {
        leftVal = "";
        displayVal = leftVal;
      } else {
        rightVal = "";
        displayVal = rightVal;
      }
    }
    if (val == ".") {
      if (!dec) {
        if (firstNum) {
          leftVal += val;
          displayVal = leftVal;
          dec = true;
        } else {
          rightVal += val;
          displayVal = rightVal;
          dec = true;
        }
      }
    }
    if (val == "^") {
      opVal = '^';
      displayVal = leftVal+ rightVal;
      firstNum = false;
      dec = false;
    }
    if (val == "√") {
      if (firstNum) {
        leftVal = str(sqrt(PApplet.parseFloat(leftVal)));
        displayVal = leftVal;
      } else {
        rightVal = str(sqrt(PApplet.parseFloat(rightVal)));
        displayVal = rightVal;
      }
    }
  }
}
public void TV() {
  fill(50);
  triangle(width/1.5f, height/2.8f, width/2.85f, height/2.8f, width/2, height/4);
  fill(50);
  rect(width/2, height/6, 300, 120);
  fill(255);
  rect(width/2, height/6, 290, 110);
}
class Button {
  // Member Variables
  int x, y, w, h, v;
  int c,f,r;
  String op;
  boolean hov, asOperator;
  // Multiple constructers for numbers and other buttons
  Button(int x, int y, int w, int h, int v, int c,int f,int r) {
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.v = v;
    hov = false;
    this.c=c;
    asOperator = false;
    this.f=f;
    this.r=r;
  }
  public Button asOperator (String op) {
    this.op = op;
    asOperator = true;
    return this;
  }
  // Display Method
  public void display() {
    if (asOperator) {
      rectMode(CENTER);
      if (hov) {
        fill(r);
      } else {
        fill(c);
      }
      ellipse(x, y, w, h);
      textAlign(CENTER);
      fill(f);
      text(op, x, y+7);
    } else {
      rectMode(CENTER);
      if (hov) {
        fill(r);
      } else {
        fill(c);
      }
      rect(x, y, w, h, 5);
      textAlign(CENTER, CENTER);
      textSize(20);
      fill(93,194,30);
      text(v, x, y);
    }
  }
  // Hover Method
  public void hover() {
    hov = mouseX > x-w/2 && mouseX < x+w/2 && mouseY > y-h/2 && mouseY < y+h/2;
  }
}
  public void settings() {  size(500, 450); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--present", "--window-color=#666666", "--stop-color=#cccccc", "Calculator" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
