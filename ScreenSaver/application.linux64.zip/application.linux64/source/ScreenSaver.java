import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class ScreenSaver extends PApplet {

Line[] myLines = new Line[150];
float frames=0;
public void setup() {
  background(0);
  
  for (int i=0; i<myLines.length; i++) {
    myLines[i] = new Line(random(width), random(height), random(2, 8), random(2, 10));
  }
  frameRate(50);
  //xpos = random(width);
  //ypos = random(height);
}

public void draw() {
  frames++;
  for (int i = 0; i<myLines.length; i++) {
    myLines[i].display();
  }
  if (frames>(500)) {
    background(0);
    frames=0;
  }
}
class Line {
  // Variables
  float xpos;
  float ypos;
  float strokeW;
  float pointCount;
  float rand;

  //Constructer
  Line(float xpos, float ypos, float strokeW, float pointCount) {
    this.xpos = xpos;
    this.ypos = ypos;
    this.strokeW = strokeW;
    this.pointCount = pointCount;
    rand = 0.0f;
  }
  //Display
  public void display() {
    strokeW = random(2, 5);
    pointCount = random(2, 55);
    stroke(random(PApplet.parseFloat(168)), random(PApplet.parseFloat(300)), random(PApplet.parseFloat(300)));
    if (xpos > width || xpos < 0 || ypos > height || ypos <0) {
      xpos = random(width);
      ypos= random(height);
    } else {
      if (random(100)>70) {
        strokeWeight(strokeW);
        moveRight(xpos, ypos, pointCount);
      } else  if (random(100)>55) {
        strokeWeight(strokeW);
        moveLeft(xpos, ypos, pointCount);
      } else  if (random(100)>50) {
        strokeWeight(strokeW);
        moveDown(xpos, ypos, pointCount);
      } else {
        strokeWeight(strokeW);
        moveUp(xpos, ypos, pointCount);
      }
    }
  }
  //Movement
  public void moveRight(float startX, float startY, float moveCount) {
    for (float i=0; i<moveCount; i++) {
      point(startX+i, startY);
      xpos = startX + i;
      ypos = startY;
    }
  }

  public void moveLeft(float startX, float startY, float moveCount) {
    for (float i=0; i<moveCount; i++) {
      point(startX-i, startY);
      xpos = startX - i;
      ypos = startY;
    }
  }

  public void moveUp(float startX, float startY, float moveCount) {
    for (float i=0; i<moveCount; i++) {
      point(startX, startY - i);
      xpos = startX;
      ypos = startY - i;
    }
  }

  public void moveDown(float startX, float startY, float moveCount) {
    for (float i=0; i<moveCount; i++) {
      point(startX, startY + i);
      xpos = startX;
      ypos = startY + i;
    }
  }
}
  public void settings() {  size(displayWidth, displayHeight); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--present", "--window-color=#666666", "--stop-color=#cccccc", "ScreenSaver" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
